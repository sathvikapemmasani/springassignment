package com.cg.productCatalogue.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.productCatalogue.dao.IcatalogueDao;
import com.cg.productCatalogue.dto.Products;

@Service
public class CatalogueImp implements Icatalogue{
	@Autowired
	IcatalogueDao dao;

	@Override
	public Integer createProduct(Products products) {
		// TODO Auto-generated method stub
		return dao.createProduct(products);
	}

	@Override
	public Integer deleteProduct(String productId) {
		// TODO Auto-generated method stub
		return dao.deleteProduct(productId);
	}

	@Override
	public Products getbyId(String productId) {
		// TODO Auto-generated method stub
		return  dao.getbyId(productId);
	}

	@Override
	public List<Products> getAllProducts() {
		// TODO Auto-generated method stub
		return dao.getAllProducts();
	}

	

}
