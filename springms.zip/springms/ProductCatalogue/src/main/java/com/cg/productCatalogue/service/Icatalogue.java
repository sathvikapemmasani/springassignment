package com.cg.productCatalogue.service;

import java.util.List;

import com.cg.productCatalogue.dto.Products;


public interface Icatalogue {
	public Integer createProduct(Products products);

	public Integer deleteProduct(String productId);

public Products getbyId(String productId);
	
	public List<Products> getAllProducts();

}
