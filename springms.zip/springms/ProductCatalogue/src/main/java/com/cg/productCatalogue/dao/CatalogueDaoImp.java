package com.cg.productCatalogue.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.productCatalogue.dto.Products;

@Repository
public class CatalogueDaoImp implements IcatalogueDao{
	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public Integer createProduct(Products products) {
		// TODO Auto-generated method stub
		mongoTemplate.save(products);
		return 1;
	}

	@Override
	public Integer deleteProduct(String productId) {
		// TODO Auto-generated method stub
		List<Products> products=mongoTemplate.findAll(Products.class);
		for (Products products2 : products) {
			if(products2.getProductId().equals(productId)) {
				
				mongoTemplate.remove(products2);
				return 1;
			}
			
		}
		
			return null;
	}

	@Override
	public Products getbyId(String productId) {
		// TODO Auto-generated method stub
		List<Products> t=mongoTemplate.findAll(Products.class) ;
		for (Products products : t) {
			if(products.getProductId().equals(productId)) {
				return products;
			}
		}
		//System.out.println(t);
		return null;
	}

	@Override
	public List<Products> getAllProducts() {
		
		return mongoTemplate.findAll(Products.class);
	}

	

}
