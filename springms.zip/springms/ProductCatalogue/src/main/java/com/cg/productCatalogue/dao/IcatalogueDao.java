package com.cg.productCatalogue.dao;

import java.util.List;

import com.cg.productCatalogue.dto.Products;


public interface IcatalogueDao {
	public Integer createProduct(Products products);

	public Integer deleteProduct(String productId);

	public Products getbyId(String productId);
	
	public List<Products> getAllProducts();
}
