package com.example.consumer;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Controllerconsumer {
	@Autowired
	AccountRepository a;
	
	@GetMapping("/accountList")
	public List<Dto> accountList() {
		
		//model.addAttribute("accounts", a.getAllAccounts());
		return a.getAllAccounts();
	}
	
	@GetMapping("/accountDetails")
	public Dto accountDetails(@PathVariable String id1) {
		//model.addAttribute("account", a.getAccount(id));
		System.out.println("id is"+id1);
		return a.getAccount(id1);
		
	}
	

}
