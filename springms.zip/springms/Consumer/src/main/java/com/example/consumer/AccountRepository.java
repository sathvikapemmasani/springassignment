package com.example.consumer;

import java.util.List;

public interface AccountRepository {
    List<Dto> getAllAccounts();
	Dto getAccount(String number);

}
