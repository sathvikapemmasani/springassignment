package com.example.consumer;

public class Dto {

	private String name;
	private String id;
	private double sal;
	public Dto() {
		
	
	}
	public Dto(String name, String id, double sal) {
		super();
		this.name = name;
		this.id = id;
		this.sal = sal;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public double getSal() {
		return sal;
	}
	public void setSal(double sal) {
		this.sal = sal;
	}
	@Override
	public String toString() {
		return "Dto [name=" + name + ", id=" + id + ", sal=" + sal + "]";
	}
	



}
