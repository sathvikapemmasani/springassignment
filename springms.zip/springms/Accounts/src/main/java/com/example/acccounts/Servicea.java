package com.example.acccounts;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class Servicea {
	@Autowired
	Dao d;
	public Integer createproduct(Dto dt) {
		return d.Createproduct(dt);
		
	}
	public Integer Deleteproduct(Integer id) {
		return d.Deleteproduct(id);
	}
	
public List<Dto> getprod(){
	return d.getprod();
}
public Dto getbyid(String id){
	return d.getbyid(id);
}

}
