package com.example.acccounts;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

@Repository
public class Dao {
	@Autowired
	MongoTemplate m;
	public Integer Createproduct(Dto d) {
		m.save(d);
		return 1;
		
	}
	public Integer Deleteproduct(Integer id) {
		Dto products=m.findById(id, Dto.class);
		m.remove(products);
		if(products!=null)
		return 1;
		else
			return 0;
	}
	public List<Dto> getprod(){
		return m.findAll(Dto.class);
	}
	
public Dto getbyid(String id){
	Dto t=m.findById(id, Dto.class);
	return t;
	
	
}
}
