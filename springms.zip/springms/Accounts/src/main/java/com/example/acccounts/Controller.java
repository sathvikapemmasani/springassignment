package com.example.acccounts;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/user")
public class Controller {
	@Autowired
	Servicea s;
	
	@PostMapping("/create")
	public Integer createProduct(@RequestBody Dto product) {
		return s.createproduct(product);
		
	}
	@DeleteMapping("/delete/{id}")
	public Integer deleteProduct(@RequestParam("id") Integer id) {
		return s.Deleteproduct(id);
		
	}
	
	@GetMapping("/get")
	public List<Dto> getProduct() {
		System.out.println("in get");
		return s.getprod();
		
	}
	@GetMapping("/getid")
	public Dto getbyid(@RequestParam String id){
		System.out.println("in conroller"+id);
		return s.getbyid(id);
	}

}
