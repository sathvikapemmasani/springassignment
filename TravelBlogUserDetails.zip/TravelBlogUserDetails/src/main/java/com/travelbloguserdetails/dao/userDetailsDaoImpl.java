package com.travelbloguserdetails.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.travelbloguserdetails.dto.User;

@Repository
public class userDetailsDaoImpl implements userDetails{
	
	@Autowired
	MongoTemplate mongoTemplate;


	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return mongoTemplate.insert(user);
	}


	@Override
	public List<User> getUsers() {
		// TODO Auto-generated method stub
		return mongoTemplate.findAll(User.class);
	}

}
