package com.travelbloguserdetails;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@EnableEurekaClient
@SpringBootApplication
public class TravelBlogUserDetailsApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelBlogUserDetailsApplication.class, args);
		System.out.println("in travelblog user details main");
		
	}

}
