package com.cg.travelblog.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.travelblog.dto.User;
import com.cg.travelblog.service.userService;

@RestController
@RequestMapping("/TravelBloguserController")
public class userController {
	@Autowired
	userService userService;
	
	
	@PostMapping("/addUser")
	public User addUsers(@RequestBody User user) {
		return userService.addUser(user);
	}
	

}
