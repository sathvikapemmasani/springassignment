package com.cg.travelblog.dao;


import com.cg.travelblog.dto.User;

public interface userDao {
	public User addUser(User user);
	
	
}
