package com.cg.travelblog.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.travelblog.dao.userDao;
import com.cg.travelblog.dto.User;

@Service
public class userServiceImpl implements userService {
	
	@Autowired
	userDao userDao;

	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return userDao.addUser(user);
				
	}
	

}
