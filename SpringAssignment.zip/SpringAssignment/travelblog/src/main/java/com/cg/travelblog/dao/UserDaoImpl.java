package com.cg.travelblog.dao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.travelblog.dto.User;

@Repository
public class UserDaoImpl implements userDao{
	
	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public User addUser(User user) {
		// TODO Auto-generated method stub
		return mongoTemplate.insert(user);
	}

}
