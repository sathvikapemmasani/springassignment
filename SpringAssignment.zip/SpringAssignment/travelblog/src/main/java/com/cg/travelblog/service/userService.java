package com.cg.travelblog.service;

import com.cg.travelblog.dto.User;

public interface userService {
	public User addUser(User user);

}
