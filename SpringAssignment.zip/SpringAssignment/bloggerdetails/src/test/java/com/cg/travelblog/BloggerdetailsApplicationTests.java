package com.cg.travelblog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BloggerdetailsApplicationTests {

	@Test
	void contextLoads() {
	}

}
