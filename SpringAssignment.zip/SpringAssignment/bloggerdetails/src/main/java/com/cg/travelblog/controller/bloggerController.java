package com.cg.travelblog.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.cg.travelblog.dto.BloggerDetails;

import com.cg.travelblog.service.bloggerService;

@RestController
@RequestMapping("/bloggercontroller")
public class bloggerController {
	@Autowired
	bloggerService bloggerService;
	
	@PostMapping("/addBlogs")
	public BloggerDetails addUsers(@RequestBody BloggerDetails bloggerDetails) {
		return bloggerService.addBlog(bloggerDetails);
	}
	
	@GetMapping("/getBlogByDestination/{destination}")
	public List<BloggerDetails> getDestination(@PathVariable("destination") String destination) {
		return bloggerService.searchByDestination(destination);
	}
	
}
