package com.cg.travelblog.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "blogger_details")
public class BloggerDetails {
	/*@Id
	@Indexed(name="_id")
	private Integer blogId;*/
	//private User user;
	private String travelexperience;
	private String country;
	private String destinations;
	public String getTravelexperience() {
		return travelexperience;
	}
	public void setTravelexperience(String travelexperience) {
		this.travelexperience = travelexperience;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getDestinations() {
		return destinations;
	}
	public void setDestinations(String destinations) {
		this.destinations = destinations;
	}
	@Override
	public String toString() {
		return "BloggerDetails [travelexperience=" + travelexperience + ", country=" + country + ", destinations="
				+ destinations + "]";
	}
	public BloggerDetails(String travelexperience, String country, String destinations) {
		super();
		this.travelexperience = travelexperience;
		this.country = country;
		this.destinations = destinations;
	}
	public BloggerDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
