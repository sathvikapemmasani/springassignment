package com.cg.travelblog.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.cg.travelblog.dto.BloggerDetails;

public interface bloggerService {
	public BloggerDetails addBlog(BloggerDetails bloggerDetails);
	public List<BloggerDetails> searchByDestination(String destinations);


}
