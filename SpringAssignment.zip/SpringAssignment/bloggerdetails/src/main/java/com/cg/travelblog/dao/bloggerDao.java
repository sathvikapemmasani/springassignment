package com.cg.travelblog.dao;

import java.util.List;

import com.cg.travelblog.dto.BloggerDetails;


public interface bloggerDao {
	public BloggerDetails addBlog(BloggerDetails bloggerDetails);
	public List<BloggerDetails> searchByDestination(String destinations);

}
