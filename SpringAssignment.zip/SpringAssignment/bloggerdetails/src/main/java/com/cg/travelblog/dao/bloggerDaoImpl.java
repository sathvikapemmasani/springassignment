package com.cg.travelblog.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Repository;

import com.cg.travelblog.dto.BloggerDetails;

@Repository
public class bloggerDaoImpl implements bloggerDao{

	@Autowired
	MongoTemplate mongoTemplate;

	@Override
	public BloggerDetails addBlog(BloggerDetails bloggerDetails) {
		// TODO Auto-generated method stub
		return mongoTemplate.insert(bloggerDetails);
	}

	

	public List<BloggerDetails> searchByDestination(String destinations) {
		// TODO Auto-generated method stub
		List<BloggerDetails> details=mongoTemplate.findAll(BloggerDetails.class);
		List<BloggerDetails> blogdetails=new ArrayList<BloggerDetails>();
		for(BloggerDetails detail:details) {
			if(detail.getDestinations().equalsIgnoreCase(destinations)) {
				blogdetails.add(detail);
			
			}
		}
		return blogdetails;
	}
}
