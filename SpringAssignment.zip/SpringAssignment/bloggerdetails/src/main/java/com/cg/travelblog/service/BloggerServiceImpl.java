package com.cg.travelblog.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.travelblog.dao.bloggerDao;
import com.cg.travelblog.dto.BloggerDetails;

@Service
public class BloggerServiceImpl implements bloggerService {
	
	@Autowired
	bloggerDao bloggerDao;

	@Override
	public BloggerDetails addBlog(BloggerDetails bloggerDetails) {
		// TODO Auto-generated method stub
		return bloggerDao.addBlog(bloggerDetails);
	}

	@Override
	public List<BloggerDetails> searchByDestination(String destinations) {
		// TODO Auto-generated method stub
		return bloggerDao.searchByDestination(destinations);
	}

}
