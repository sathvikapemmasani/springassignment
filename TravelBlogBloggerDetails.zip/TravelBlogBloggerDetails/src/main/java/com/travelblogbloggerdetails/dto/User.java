package com.travelblogbloggerdetails.dto;

import org.springframework.data.mongodb.core.mapping.Document;


public class User {
	private Long contactNo;
	private String name;
	private String address;
	private Integer age;
	private String password;
	private String securityquestion;
	private String securityanswer;
	public Long getContactNo() {
		return contactNo;
	}
	public void setContactNo(Long contactNo) {
		this.contactNo = contactNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public Integer getAge() {
		return age;
	}
	public void setAge(Integer age) {
		this.age = age;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getSecurityquestion() {
		return securityquestion;
	}
	public void setSecurityquestion(String securityquestion) {
		this.securityquestion = securityquestion;
	}
	public String getSecurityanswer() {
		return securityanswer;
	}
	public void setSecurityanswer(String securityanswer) {
		this.securityanswer = securityanswer;
	}
	public User(Long contactNo, String name, String address, Integer age, String password, String securityquestion,
			String securityanswer) {
		super();
		this.contactNo = contactNo;
		this.name = name;
		this.address = address;
		this.age = age;
		this.password = password;
		this.securityquestion = securityquestion;
		this.securityanswer = securityanswer;
	}
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "User [contactNo=" + contactNo + ", name=" + name + ", address=" + address + ", age=" + age
				+ ", password=" + password + ", securityquestion=" + securityquestion + ", securityanswer="
				+ securityanswer + "]";
	}
	

}
