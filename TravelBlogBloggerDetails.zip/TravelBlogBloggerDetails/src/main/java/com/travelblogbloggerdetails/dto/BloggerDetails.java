package com.travelblogbloggerdetails.dto;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class BloggerDetails {

	private String userName;
	private Long contactNo;
		public Long getContactNo() {
		return contactNo;
	}
	public void setContactNo(Long contactNo) {
		this.contactNo = contactNo;
	}
		public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
		private String travelexperience;
		private String country;
		private String destinations;
		public String getTravelexperience() {
			return travelexperience;
		}
		public void setTravelexperience(String travelexperience) {
			this.travelexperience = travelexperience;
		}
		public String getCountry() {
			return country;
		}
		public void setCountry(String country) {
			this.country = country;
		}
		public String getDestinations() {
			return destinations;
		}
		public void setDestinations(String destinations) {
			this.destinations = destinations;
		}
		
		@Override
		public String toString() {
			return "BloggerDetails [userName=" + userName + ", contactNo=" + contactNo + ", travelexperience="
					+ travelexperience + ", country=" + country + ", destinations=" + destinations + "]";
		}
		public BloggerDetails(String userName, Long contactNo, String travelexperience, String country,
				String destinations) {
			super();
			this.userName = userName;
			this.contactNo = contactNo;
			this.travelexperience = travelexperience;
			this.country = country;
			this.destinations = destinations;
		}
		public BloggerDetails() {
			super();
			// TODO Auto-generated constructor stub
		}
		
}
