package com.travelblogbloggerdetails.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.travelblogbloggerdetails.dao.bloggerDeatilsDao;
import com.travelblogbloggerdetails.dto.BloggerDetails;
import com.travelblogbloggerdetails.dto.User;

@Service
public class bloggerDetailsServiceImpl implements bloggerDeatilsService{
	
	@Autowired
	bloggerDeatilsDao bloggerDeatilsDao;

	@Override
	public BloggerDetails addBlog(BloggerDetails bloggerDetails) {
		// TODO Auto-generated method stub
		return bloggerDeatilsDao.addBlog(bloggerDetails);
	}

	@Override
	public List<BloggerDetails> searchByDestination(String destinations) {
		// TODO Auto-generated method stub
		return bloggerDeatilsDao.searchByDestination(destinations);
	}

	@Override
	public List<BloggerDetails> getAllBlogs() {
		// TODO Auto-generated method stub
		return bloggerDeatilsDao.getAllBlogs();
	}

	
	  @Override 
	  public List<User> getUsers() { // TODO Auto-generated method stub
	  return bloggerDeatilsDao.getUsers(); 
	  }
	 

}
