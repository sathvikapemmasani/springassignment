package com.travelblogbloggerdetails.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.travelblogbloggerdetails.dto.BloggerDetails;
import com.travelblogbloggerdetails.dto.User;
import com.travelblogbloggerdetails.service.bloggerDeatilsService;

@RestController
@RequestMapping("/bloggercontroller")
public class bloggerDetailsController {
	@Autowired
	bloggerDeatilsService bloggerDeatilsService;
	@PostMapping("/addBlogs")
	public ResponseEntity<String> addBlogs(@RequestBody BloggerDetails bloggerDetails) {
		
		
		 BloggerDetails b=bloggerDeatilsService.addBlog(bloggerDetails);	
		 if(b!= null) {
		 return new ResponseEntity<>("Added blogger details successfully",HttpStatus.OK);
		}
		else
			return new ResponseEntity<>("Register to add blogs",HttpStatus.BAD_REQUEST);
		
	}
	
	@GetMapping("/getBlogByDestination/{destination}")
	public List<BloggerDetails> getDestination(@PathVariable("destination") String destination) {
		System.out.println("in blog controller destination");
		return bloggerDeatilsService.searchByDestination(destination);
	}
	
	@GetMapping("/getAllBlogs")
	public List<BloggerDetails> getAllBlogs(){
		return bloggerDeatilsService.getAllBlogs();
	}
	
	
	  @GetMapping("/getusersblog") 
	  public List<User> getUsers() {
	  
	  return bloggerDeatilsService.getUsers(); 
	  }
	 

}
